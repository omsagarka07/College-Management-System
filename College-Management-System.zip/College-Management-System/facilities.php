<!DOCTYPE html>
<html lang="en">

<head>
    <title>Royal Technical Colleges</title>
    <link rel="shortcut icon" href="Images/LOGO.jpeg" type="image/x-icon">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5 & Font Awesome -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <!-- Custom CSS -->
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f8f9fa;
        }

        .flip-card {
            background-color: transparent;
            width: 100%;
            perspective: 1000px;
            margin-bottom: 2rem;
        }

        .flip-card-inner {
            position: relative;
            width: 100%;
            min-height: 400px;
            transition: transform 0.8s;
            transform-style: preserve-3d;
        }

        .flip-card:hover .flip-card-inner {
            transform: rotateY(180deg);
        }

        .flip-card-front, .flip-card-back {
            position: absolute;
            width: 100%;
            height: 100%;
            backface-visibility: hidden;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .flip-card-front {
            background-color: #fff;
        }

        .flip-card-front img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .flip-card-back {
            background-color: #003366;
            color: white;
            transform: rotateY(180deg);
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem;
            text-align: center;
        }

        .flip-card-back h2 {
            font-weight: 700;
            margin-bottom: 1rem;
        }

        .flip-card-back p {
            line-height: 1.6;
        }

        @media (max-width: 767px) {
            .flip-card-inner {
                min-height: 300px;
            }

            .flip-card-back {
                padding: 1rem;
            }

            .flip-card-back h2 {
                font-size: 1.5rem;
            }
        }
    </style>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>

<?php include('common/header.php') ?>

<div class="container py-5">

    <div class="flip-card">
        <div class="flip-card-inner">
            <div class="flip-card-front">
                <img src="Images/a1.jpg" alt="Clean & Green Campus">
            </div>
            <div class="flip-card-back">
                <div>
                    <h2>Clean & Green Campus</h2>
                    <p>Our college campus offers a beautiful, serene environment, with peaceful walkways lined with
                        trees and vibrant greenery...</p>
                </div>
            </div>
        </div>
    </div>

    <div class="flip-card">
        <div class="flip-card-inner">
            <div class="flip-card-front">
                <img src="Images/a2.jpg" alt="NCC Unit">
            </div>
            <div class="flip-card-back">
                <div>
                    <h2>NCC Unit</h2>
                    <p>Our college is proud to host an NCC unit that builds leadership, discipline, and a spirit of
                        service...</p>
                </div>
            </div>
        </div>
    </div>

    <div class="flip-card">
        <div class="flip-card-inner">
            <div class="flip-card-front">
                <img src="Images/a3.jpg" alt="Resource Utilization Centre">
            </div>
            <div class="flip-card-back">
                <div>
                    <h2>Resource Utilization Centre</h2>
                    <p>The library offers a wide collection of academic resources, digital materials, and study spaces...</p>
                </div>
            </div>
        </div>
    </div>

    <div class="flip-card">
        <div class="flip-card-inner">
            <div class="flip-card-front">
                <img src="Images/a4.jpg" alt="RTO Services">
            </div>
            <div class="flip-card-back">
                <div>
                    <h2>RTO Services</h2>
                    <p>Situated within the campus, the RTO office offers essential services such as vehicle registration...</p>
                </div>
            </div>
        </div>
    </div>

    <div class="flip-card">
        <div class="flip-card-inner">
            <div class="flip-card-front">
                <img src="Images/a5.jpg" alt="Developed Parking Area">
            </div>
            <div class="flip-card-back">
                <div>
                    <h2>Developed Parking Area</h2>
                    <p>A well-organized parking space with green surroundings ensures safe and convenient vehicle parking...</p>
                </div>
            </div>
        </div>
    </div>

    <div class="flip-card">
        <div class="flip-card-inner">
            <div class="flip-card-front">
                <img src="Images/a6.jpg" alt="Hostel Facility">
            </div>
            <div class="flip-card-back">
                <div>
                    <h2>Hostel Facility</h2>
                    <p>Separate hostel facilities for boys and girls, equipped with security, clean dining, and
                        study-friendly environments...</p>
                </div>
            </div>
        </div>
    </div>

    <div class="flip-card">
        <div class="flip-card-inner">
            <div class="flip-card-front">
                <img src="Images/a7.jpg" alt="Cricket Ground">
            </div>
            <div class="flip-card-back">
                <div>
                    <h2>Cricket Ground</h2>
                    <p>Our cricket ground is a hub for sports, hosting tournaments and practice sessions that encourage
                        a healthy, active lifestyle...</p>
                </div>
            </div>
        </div>
    </div>

</div>

<?php include('common/footer.php') ?>

</body>

</html>
