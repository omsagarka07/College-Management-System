<footer>
  <div class="footer-top">
    <div class="container">
        <div class="row">
          <div class="col-md-3 col-sm-6 col-xs-12 segment-one md-mb-30 sm-mb-30">
            <h3>Royal Technical College</h3>
            <p>This project has been developed by the team at Royal Technical College with dedication and a passion for learning.
              The purpose of this project is to promote education in computer languages and modern technologies.
              We hope you enjoy exploring it. Thank you for visiting!
            </p>
          </div>
          <div class="col-md-2 col-sm-6 col-xs-12 segment-two md-mb-30 sm-mb-30">
            <h2>Quick Links</h2>
            <ul>
              <li><a href="">About RTC</a></li>
              <li><a href="">Admissions Policy</a></li>
              <li><a href="">Apply for Admission</a></li>
              <li><a href="">Download Prospectus</a></li>
              <li><a href="">Contact Us</a></li>
            </ul>
          </div>
          <div class="col-md-4 col-sm-6 col-xs-12 segment-two md-mb-30 sm-mb-30">
            <h2>Undergraduate Programs</h2>
            <ul>
              <li><a href="">B.Sc. Civil Engineering</a></li>
              <li><a href="">B.Sc. Electrical Engineering</a></li>
              <li><a href="">B.Sc. Mechanical Engineering</a></li>
              <li><a href="">Bachelor of Architecture</a></li>
              <li><a href="">BS Computer Science</a></li>
              <li><a href="">Bachelor of Business Administration</a></li>
            </ul>
          </div>  
          <div class="col-md-3 col-sm-6 col-xs-12 segment-two md-mb-30 sm-mb-30">
  <h2>Contact Details</h2>
  <p>Address: Royal Technical College, Near ITI College, Chhaya Main Road, Porbandar, Gujarat – 360575</p>
  <p>Telephone: (+91 286) 2211111</p>
  <p>Email: admissions@rtc.edu.in</p>
</div>


      </div>
    </div>
  </div>
  <p class="footer-bottom-text">Copyright © Royal Technical College. All rights reserved. 2025</p>
</footer>
