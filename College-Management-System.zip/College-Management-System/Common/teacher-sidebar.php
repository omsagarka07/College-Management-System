<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Teacher Sidebar</title>
  
  <!-- Bootstrap 4.6 CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.6.0/css/bootstrap.min.css">
  
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  
  <!-- Custom CSS -->
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    .sidebar {
      height: 100vh;
      background-color: #343a40;
      padding-top: 1rem;
      transition: all 0.3s;
      overflow-y: auto;
      z-index: 999;
    }

    .sidebar .nav-link {
      color: #fff;
      padding: 0.75rem 1rem;
      transition: 0.3s;
    }

    .sidebar .nav-link:hover {
      background-color: #495057;
      color: #fff;
    }

    .show-sidebar {
      transform: translateX(0) !important;
    }

    .sidebar {
      transform: translateX(-100%);
    }

    @media (min-width: 992px) {
      .sidebar {
        transform: translateX(0);
      }

      .show-btn {
        display: none;
      }
    }

    .show-btn {
      margin: 10px;
      background-color: #343a40;
      color: #fff;
      border: none;
      border-radius: 5px;
      padding: 5px 10px;
      cursor: pointer;
    }

    .show-btn:hover {
      background-color: #495057;
    }
  </style>
</head>
<body>

  <div class="row w-100">
    <button class="show-btn ml-auto">
      <i class="fa fa-bars py-1" aria-hidden="true"></i>
    </button>
  </div>

  <nav id="sidebarMenu">
    <div class="col-xl-2 col-lg-3 col-md-4 sidebar position-fixed border-right">
      <div class="sidebar-header">
        <a class="nav-link text-white" href="../teacher/teacher-index.php">
          <i class="fa fa-home mr-2" aria-hidden="true"></i> Dashboard
        </a>
      </div>
      <ul class="nav flex-column">
        <li class="nav-item">
          <a class="nav-link" href="../admin/display-teacher.php">
            <i class="fa fa-user mr-2" aria-hidden="true"></i> Personal Profile
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="../teacher/teacher-personal-information.php">
            <i class="fa fa-info-circle mr-2" aria-hidden="true"></i> Personal Information
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="../teacher/teacher-courses.php">
            <i class="fa fa-address-book mr-2" aria-hidden="true"></i> Teacher Courses
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="../teacher/student-attendance.php">
            <i class="fa fa-check-circle mr-2" aria-hidden="true"></i> Student Attendance
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="../teacher/class-result.php">
            <i class="fa fa-users mr-2" aria-hidden="true"></i> Class Results
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="../teacher/teacher-password.php">
            <i class="fa fa-key mr-2" aria-hidden="true"></i> Change Password
          </a>
        </li>
      </ul>
    </div>
  </nav>

  <!-- JavaScript -->
  <script>
    const toggleBtn = document.querySelector(".show-btn");
    const sidebar = document.querySelector(".sidebar");

    toggleBtn.addEventListener("click", function () {
      sidebar.classList.toggle("show-sidebar");
    });
  </script>

  <!-- Bootstrap JS and dependencies -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
