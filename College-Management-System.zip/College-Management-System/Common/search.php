<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>College Website Search</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    body {
      background-color: #fdfdfd;
      font-family: 'Segoe UI', sans-serif;
    }
    .search-results {
      margin-top: 30px;
    }
    .result-card {
      border: 1px solid #ddd;
      border-radius: 8px;
      margin-bottom: 20px;
      padding: 15px;
      background-color: #fff;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
    }
    .result-title {
      font-size: 1.2em;
      font-weight: bold;
      color: #007bff;
    }
    .result-details {
      font-size: 0.95em;
      color: #555;
    }
  </style>
</head>
<body>
  <div class="container mt-5">
    <h1 class="text-center mb-4">College Website Search</h1>

    <!-- Search Form -->
    <form class="form-inline mb-4 justify-content-center" method="GET" action="">
      <input class="form-control mr-2 w-75" type="search" placeholder="Search departments, courses, faculty, news..." name="query" value="<?php echo isset($_GET['query']) ? htmlspecialchars($_GET['query']) : ''; ?>">
      <button class="btn btn-primary" type="submit">Search</button>
    </form>

    <!-- Search Results -->
    <div class="search-results">
      <?php
      // Simulated data (replace with actual DB data in real use)
      $college_data = [
        ["type" => "department", "title" => "Computer Science Department", "description" => "Programs in software development, data science, and AI."],
        ["type" => "course", "title" => "Introduction to Programming", "details" => "Covers basic programming concepts using Python."],
        ["type" => "faculty", "name" => "Dr. Smith", "expertise" => "Electrical Engineering, specializing in power systems."],
        ["type" => "news", "headline" => "Upcoming Robotics Workshop", "content" => "Three-day workshop on robotics."],
        ["type" => "department", "title" => "Mechanical Engineering Department", "description" => "Focuses on design, manufacturing, and thermal engineering."],
        ["type" => "course", "title" => "Calculus I", "details" => "First-year course covering differential calculus."],
        ["type" => "faculty", "name" => "Dr. Jones", "expertise" => "CS Professor, research in machine learning."],
        ["type" => "news", "headline" => "Project Wins National Award", "content" => "Students won a national innovation award."],
      ];

      if (isset($_GET['query']) && !empty(trim($_GET['query']))) {
        $query = strtolower(trim($_GET['query']));
        echo "<h4>Search Results for: <span class='text-primary'>\"" . htmlspecialchars($_GET['query']) . "\"</span></h4><hr>";
        $found = false;

        foreach ($college_data as $item) {
          $match = false;

          switch ($item['type']) {
            case "department":
              $match = stripos($item['title'], $query) !== false || stripos($item['description'], $query) !== false;
              break;
            case "course":
              $match = stripos($item['title'], $query) !== false || stripos($item['details'], $query) !== false;
              break;
            case "faculty":
              $match = stripos($item['name'], $query) !== false || stripos($item['expertise'], $query) !== false;
              break;
            case "news":
              $match = stripos($item['headline'], $query) !== false || stripos($item['content'], $query) !== false;
              break;
          }

          if ($match) {
            echo "<div class='result-card'>";
            switch ($item['type']) {
              case "department":
                echo "<h5 class='result-title'>Department: " . htmlspecialchars($item['title']) . "</h5>";
                echo "<p class='result-details'>" . htmlspecialchars($item['description']) . "</p>";
                break;
              case "course":
                echo "<h5 class='result-title'>Course: " . htmlspecialchars($item['title']) . "</h5>";
                echo "<p class='result-details'>" . htmlspecialchars($item['details']) . "</p>";
                break;
              case "faculty":
                echo "<h5 class='result-title'>Faculty: " . htmlspecialchars($item['name']) . "</h5>";
                echo "<p class='result-details'>Expertise: " . htmlspecialchars($item['expertise']) . "</p>";
                break;
              case "news":
                echo "<h5 class='result-title'>News: " . htmlspecialchars($item['headline']) . "</h5>";
                echo "<p class='result-details'>" . htmlspecialchars($item['content']) . "</p>";
                break;
            }
            echo "</div>";
            $found = true;
          }
        }

        if (!$found) {
          echo "<p class='text-danger'>No results found for your search.</p>";
        }
      } else {
        echo "<p class='text-muted'>Please enter a search term above to find information about departments, courses, faculty, or news.</p>";
      }
      ?>
    </div>
  </div>

  <!-- Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
