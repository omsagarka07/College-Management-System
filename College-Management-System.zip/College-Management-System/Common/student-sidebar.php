<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Royal Technical Colleges</title>
    <link rel="shortcut icon" href="../Images/LOGO.jpeg" type="image/x-icon">

  <!-- Bootstrap 4 CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <style>
    body {
      margin: 0;
      padding: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    .sidebar {
      height: 100vh;
      background-color: #343a40;
      transition: all 0.3s ease;
      overflow-y: auto;
      z-index: 1000;
    }

    .sidebar-header {
      padding: 1rem;
      background-color: #23272b;
      color: white;
      text-align: center;
      font-size: 1.2rem;
      font-weight: bold;
    }

    .sidebar .nav-link {
      color: #dcdcdc;
      padding: 10px 20px;
      transition: background 0.3s ease, color 0.3s ease;
    }

    .sidebar .nav-link:hover,
    .sidebar .nav-link.active {
      background-color: #495057;
      color: #ffffff;
      text-decoration: none;
    }

    .sidebar .fa {
      width: 20px;
      text-align: center;
    }

    .show-btn {
      background-color: #343a40;
      color: white;
      border: none;
      padding: 8px 12px;
      margin: 10px;
      border-radius: 5px;
      transition: background 0.3s ease;
    }

    .show-btn:hover {
      background-color: #23272b;
    }

    .show-sidebar {
      transform: translateX(0);
    }

    @media (max-width: 992px) {
      .sidebar {
        transform: translateX(-100%);
        position: fixed;
        top: 0;
        left: 0;
        width: 75%;
        max-width: 250px;
      }

      .show-sidebar {
        transform: translateX(0);
      }
    }

    .sidebar::-webkit-scrollbar {
      width: 6px;
    }

    .sidebar::-webkit-scrollbar-thumb {
      background-color: #6c757d;
      border-radius: 10px;
    }

    .sidebar::-webkit-scrollbar-track {
      background: transparent;
    }
  </style>
</head>
<body>

  <!-- Toggle Button -->
  <div class="row w-100">
    <button class="show-btn button-show ml-auto">
      <i class="fa fa-bars py-1" aria-hidden="true"></i>
    </button>
  </div>

  <!-- Sidebar -->
  <nav id="sidebarMenu">
    <div class="col-xl-2 col-lg-3 col-md-4 sidebar position-fixed border-right">
      <div class="sidebar-header">
        <div class="nav-item">
          <a class="nav-link text-white" href="../student/student-index.php">
            <i class="fa fa-home mr-2" aria-hidden="true"></i> Dashboard
          </a>
        </div>
      </div>
      <ul class="nav flex-column">
        <li class="nav-item">
          <a class="nav-link" href="../admin/display-student.php">
            <i class="fa fa-user mr-2" aria-hidden="true"></i> Personal Profile
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="../student/student-personal-information.php">
            <i class="fa fa-info-circle mr-2" aria-hidden="true"></i> Personal Information
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="../student/student-result.php">
            <i class="fa fa-th-list mr-2" aria-hidden="true"></i> Student Results
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="../student/student-transcript.php">
            <i class="fa fa-th-list mr-2" aria-hidden="true"></i> Student Transcript
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="../student/student-fee.php">
            <i class="fa fa-credit-card-alt mr-2" aria-hidden="true"></i> Student Fee
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="../student/student-password.php">
            <i class="fa fa-key mr-2" aria-hidden="true"></i> Change Password
          </a>
        </li>
      </ul>
    </div>
  </nav>

  <!-- Bootstrap + JS -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

  <!-- Sidebar Toggle Script -->
  <script>
    const toggleBtn = document.querySelector(".show-btn");
    const sidebar = document.querySelector(".sidebar");
    toggleBtn.addEventListener("click", function () {
      sidebar.classList.toggle("show-sidebar");
    });
  </script>
</body>
</html>
