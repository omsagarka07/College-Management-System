<!doctype html>
<html lang="en">
  <head>
    <title>Royal Technical Colleges</title>
    <link rel="shortcut icon" href="Images/LOGO.jpeg" type="image/x-icon">

    <!-- Bootstrap and Custom CSS -->
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/footer.css">
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Custom Styling -->
    <style>
      .header-back {
        background: linear-gradient(135deg, #004e92, #000428);
        box-shadow: 0 4px 6px rgba(0,0,0,0.3);
      }

      .navbar-brand h3 {
        font-size: 1.4rem;
        font-weight: bold;
        margin-bottom: 0;
      }

      .logo-image {
        border-radius: 50% !important;
        border: 2px solid #fff;
        object-fit: cover;
        width: 50px;
        height: 50px;
      }

      img {
        border-radius: 50% !important;
        object-fit: cover;
      }

      .navbar-nav .nav-link {
        color: #fff !important;
        font-weight: 500;
        letter-spacing: 0.5px;
        padding: 8px 16px;
        transition: 0.3s ease-in-out;
      }

      .navbar-nav .nav-link:hover {
        color: #ffd700 !important;
        background-color: rgba(255,255,255,0.1);
        border-radius: 5px;
      }

      .navbar-toggler {
        border: none;
      }

      .navbar-toggler:focus {
        outline: none;
      }



      
      body {
      background-color: #f8f9fa;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    
    .marq {
      padding: 15px 0;
      color: white;
      font-weight: bold;
      font-size: 1.2rem;
      border-radius: 5px;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    }

    .headline {
      display: inline-block;
      margin-right: 50px;
      font-size: 1.5rem;
    }

    .subtext {
      display: inline-block;
      font-size: 1rem;
    }
    </style>
  </head>

  <body>
    <nav class="navbar navbar-expand-lg navbar-dark header-back sticky-top header-navbar-fonts">
      <a class="navbar-brand d-flex align-items-center" href="../index.php">
        <img src="../Images/LOGO.jpeg" class="logo-image" alt="Logo">
        <h3 class="text-light text-uppercase ml-2">Royal Technical Colleges</h3>
      </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown"
        aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="../index.php">HOME</a>
          </li>
          <li class="nav-item active">
                <a class="nav-link" href="../facilities.php">FACILITIES</a>
          </li>
          <li class="nav-item active">
                <a class="nav-link" href="../gallery.php">GALLERY</a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="../departments.php">DEPARTMENTS</a>
            </li>
          <li class="nav-item active">
            <a class="nav-link" href="../academics.php">ACADEMICS</a>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="../admission.php">ADMISSION</a>
          </li>
          <li class="nav-item active">
                <a class="nav-link" href="../login/login.php">
                    <i class="fa fa-sign-in text-white fa-lg" aria-hidden="true"></i> LOGIN
                </a>
            </li>
        </ul>
      </div>
    </nav>

    <marquee class="marq bg-primary text-white rounded shadow" direction="left" scrollamount="6">
      <span class="headline">🎓 Welcome to Royal Technical College of Engineering!</span>
      <span class="subtext">📢 Admissions Open | 💼 Campus Recruitment Drive | ⚙️ Annual Tech Fest - May 2025</span>
    </marquee>

  </body>
</html>
