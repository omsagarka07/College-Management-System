<!DOCTYPE html>
<html>
<head>
<title>Royal Technical Colleges</title>
<link rel="shortcut icon" href="Images/LOGO.jpeg" type="image/x-icon">
</head>
<body>
	<?php include('common/header.php') ?>

	<div class="container-fluid">
		<div class="row mb-5">
			<div class="academic-area-headings">
				<h4 class="py-4">Faculty of Engineering and Technology</h4>
			</div>
			<div class="container">
				<div class="row">
					<h4 class="dean-message-heading mt-3">Dean's Message</h4>
					<div class="col-lg-12 text-justify">
						<p>
							Welcome to the Royal Technical College, Faculty of Engineering and Technology (FOET), where we offer a wide range of engineering programs to empower the next generation of engineers. Our faculty consists of highly qualified professionals who are dedicated to providing world-class education and fostering an environment of innovation.
						</p>
						<p>
							We offer programs in Civil, Electrical, Mechanical, and Computer Engineering, each designed to prepare students for successful careers in the rapidly evolving engineering sector. Our curriculum is aligned with the latest industry standards and emphasizes practical knowledge and skills.
						</p>
						<p>
							The faculty at RTC is committed to shaping students into leaders who are capable of solving complex engineering problems and driving technological advancements. Our modern laboratories, well-equipped classrooms, and collaborative campus environment contribute to a fulfilling learning experience.
						</p>
						<p>
							Join us at RTC and be a part of an inspiring journey that will provide you with the tools to make a significant impact on the world.
						</p>
					</div>	
				</div>
			</div>
		</div>
	</div>

	<div class="container-fluid">
		<div class="row mb-5">
			<div class="academic-area-headings">
				<h4 class="py-4">Faculty of Architecture, Art and Design</h4>
			</div>
			<div class="container">
				<div class="row">
					<h4 class="dean-message-heading mt-3">Dean's Message</h4>
					<div class="col-lg-12 text-justify">
						<p>
							Welcome to the Faculty of Architecture, Art and Design at RTC. Our faculty is a vibrant community of creative thinkers and practitioners dedicated to shaping the future of architecture, design, and the visual arts.
						</p>
						<p>
							Our programs are designed to develop not only technical expertise but also creative and critical thinking skills. Students will explore a broad range of disciplines, including architecture, interior design, visual arts, and urban planning, preparing them to innovate and lead in their chosen fields.
						</p>
						<p>
							The faculty is equipped with state-of-the-art studios, design labs, and a highly qualified team of professors who are dedicated to nurturing the creativity and skills of every student. Our curriculum emphasizes both practical and theoretical learning, ensuring that our graduates are well-prepared for professional careers in design and architecture.
						</p>
						<p>
							We invite you to join our dynamic faculty and become a part of a community that is shaping the future of design, art, and architecture.
						</p>
					</div>	
				</div>
			</div>
		</div>
	</div>

	<div class="container-fluid">
		<div class="row mb-5">
			<div class="academic-area-headings">
				<h4 class="py-4">Faculty of Computer Science and Information Technology</h4>
			</div>
			<div class="container">
				<div class="row">
					<h4 class="dean-message-heading mt-3">Dean's Message</h4>
					<div class="col-lg-12 text-justify">
						<p>
							Welcome to the Faculty of Computer Science and Information Technology at RTC. Our faculty aims to produce the next generation of tech leaders who will drive innovation in the digital age.
						</p>
						<p>
							We offer a wide range of programs in computer science, IT, and software engineering that focus on both theoretical foundations and practical applications. Our faculty is dedicated to providing students with the skills and knowledge necessary to thrive in the ever-changing tech landscape.
						</p>
						<p>
							With modern computing labs, a focus on emerging technologies, and a highly skilled teaching team, we are committed to giving our students an edge in the competitive world of technology. The curriculum is regularly updated to ensure that students are well-versed in the latest industry trends and practices.
						</p>
						<p>
							We encourage you to join us and be a part of a dynamic and supportive community that will help you reach your potential and contribute to the advancement of technology.
						</p>
					</div>	
				</div>
			</div>
		</div>
	</div>

	<div class="container-fluid">
		<div class="row mb-5">
			<div class="academic-area-headings">
				<h4 class="py-4">Faculty of Business Administration</h4>
			</div>
			<div class="container">
				<div class="row">
					<h4 class="dean-message-heading mt-3">Dean's Message</h4>
					<div class="col-lg-12 text-justify">
						<p>
							Welcome to the Faculty of Business Administration at RTC. We provide a dynamic and innovative environment for students interested in pursuing careers in business, management, and entrepreneurship.
						</p>
						<p>
							Our programs are designed to develop critical thinking, leadership, and strategic decision-making skills, which are essential for success in the global business world. Our curriculum includes practical experiences, case studies, and industry collaborations that ensure students are prepared for the challenges of the modern business environment.
						</p>
						<p>
							With a team of experienced faculty and a strong focus on practical business education, we strive to develop business leaders who are capable of adapting to change, driving innovation, and leading organizations to success.
						</p>
						<p>
							We invite you to join our faculty and take the first step toward an exciting career in business.
						</p>
					</div>	
				</div>
			</div>
		</div>
	</div>

</body>
</html>
	<?php include('common/footer.php') ?>
