<?php

// Department details with Vision, Mission, and Images
$departments = [
    'computer' => [
        'name' => 'Computer Science',
        'vision' => [
            'To be a globally recognized leader in the field of computer science, fostering innovation and advancing technology.',
            'To provide cutting-edge research and education in emerging technologies.',
            'To promote a culture of creativity, critical thinking, and problem-solving.',
        ],
        'mission' => [
            'To provide high-quality education and training in computer science, emphasizing software development, artificial intelligence, and data science.',
            'To foster a collaborative environment where students engage in research and development projects.',
            'To develop technical, analytical, and leadership skills in students.',
        ],
        'topics' => [
            'Faculty' => [
                'description' => 'The Computer Science faculty consists of highly qualified professors, assistant professors, and lecturers with expertise in various fields.',
                'image' => 'img/c1.jpeg'
            ],
            'Labs' => [
                'description' => 'We have state-of-the-art labs including Software Engineering, AI, and Data Science labs equipped with the latest hardware and software tools.',
                'image' => 'img/c2.jpg'
            ],
            'Classrooms' => [
                'description' => 'Our classrooms are equipped with modern multimedia systems, projectors, and high-speed internet for an interactive learning experience.',
                'image' => 'img/c3.jpeg'
            ]
        ]
    ],
    'civil' => [
        'name' => 'Civil Engineering',
        'vision' => [
            'To become a global leader in civil engineering, shaping sustainable infrastructure for a better tomorrow.',
            'To promote innovative research in construction, environmental, and transportation engineering.',
            'To create solutions for the challenges facing the construction industry today.',
        ],
        'mission' => [
            'To provide innovative education and research in civil engineering, emphasizing sustainable design, construction, and environmental engineering.',
            'To equip students with the skills necessary for successful careers in the construction industry.',
            'To foster collaboration with industry leaders for practical research and projects.',
        ],
        'topics' => [
            'Faculty' => [
                'description' => 'The Civil Engineering faculty consists of experienced professionals with years of expertise in construction, infrastructure, and environmental engineering.',
                'image' => 'img/c11.png'
            ],
            'Labs' => [
                'description' => 'We have specialized labs for materials testing, structural analysis, and environmental engineering studies.',
                'image' => 'img/c22.avif'
            ],
            'Classrooms' => [
                'description' => 'Our classrooms are designed for collaborative learning, equipped with presentation tools and audio-visual aids.',
                'image' => 'img/c33.jpeg'
            ]
        ]
    ],
    'mechanical' => [
        'name' => 'Mechanical Engineering',
        'vision' => [
            'To excel in mechanical engineering education and research.',
            'To develop sustainable and innovative technologies.',
            'To be a center of excellence for global industry partnerships.',
        ],
        'mission' => [
            'To impart strong theoretical and practical knowledge in thermal, design, and manufacturing domains.',
            'To foster innovation, creativity, and professional ethics.',
            'To enhance industry-institute interaction for real-world exposure.',
        ],
        'topics' => [
            'Faculty' => [
                'description' => 'Highly experienced faculty members specializing in thermal engineering, CAD/CAM, and robotics.',
                'image' => 'img/m1.jpg'
            ],
            'Labs' => [
                'description' => 'Well-equipped labs for fluid mechanics, strength of materials, and mechatronics.',
                'image' => 'img/m2.jpeg'
            ],
            'Classrooms' => [
                'description' => 'Smart classrooms with 3D model visualization tools and project facilities.',
                'image' => 'img/m3.jpg'
            ]
        ]
    ],
    'electrical' => [
        'name' => 'Electrical Engineering',
        'vision' => [
            'To lead in electrical engineering education and innovation.',
            'To empower graduates with knowledge in renewable energy and automation.',
            'To support sustainable development through electrical solutions.',
        ],
        'mission' => [
            'To provide excellent teaching in electrical circuits, machines, and power systems.',
            'To promote R&D in electrical drives and embedded systems.',
            'To develop entrepreneurial and leadership skills.',
        ],
        'topics' => [
            'Faculty' => [
                'description' => 'Qualified faculty experts in power systems, electronics, and control systems.',
                'image' => 'img/e1.webp'
            ],
            'Labs' => [
                'description' => 'Advanced labs including Power Electronics, Electrical Machines, and Control Systems.',
                'image' => 'img/e2.png'
            ],
            'Classrooms' => [
                'description' => 'Interactive classrooms with electrical simulation software tools.',
                'image' => 'img/e3.webp'
            ]
        ]
    ],
];

// Get department from URL
$department = isset($_GET['department']) ? $_GET['department'] : 'computer';

// Fallback if an invalid department is selected
if (!array_key_exists($department, $departments)) {
    $department = 'computer';
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Royal Technical Colleges</title>
    <link rel="shortcut icon" href="Images/LOGO.jpeg" type="image/x-icon">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: linear-gradient(135deg, #f8f9fa, #e0f7fa);
            font-family: 'Segoe UI', sans-serif;
        }

        h1, h2, h4 {
            color: #1a237e;
        }

        .card {
            border: none;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 12px;
        }

        .card img {
            border-radius: 12px 0 0 12px;
            height: 100%;
            object-fit: cover;
        }

        .nav-pills .nav-link {
            background-color: #e3f2fd;
            color: #0d47a1;
            margin-bottom: 10px;
            font-weight: 500;
            border-radius: 8px;
        }

        .nav-pills .nav-link.active {
            background-color: #0d47a1;
            color: #fff;
        }

        .nav-pills .nav-link:hover {
            background-color: #90caf9;
            color: #000;
        }

        .dropdown-menu {
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .btn-primary {
            background-color: #1a237e;
            border: none;
        }

        .btn-primary:hover {
            background-color: #3949ab;
        }

        ul {
            list-style-type: disc;
            padding-left: 1.5rem;
        }
    </style>


</head>

<body>
    <?php include('common/header.php') ?>

    <div class="container my-5">

    <h1 class="text-center mb-4">Department Information</h1>

    <!-- Dropdown Menu -->
    <div class="mb-4 text-center">
        <div class="btn-group">
            <button class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown">Select Department</button>
            <ul class="dropdown-menu">
                <?php foreach ($departments as $key => $value): ?>
                    <li><a class="dropdown-item" href="?department=<?php echo $key; ?>"><?php echo $value['name']; ?></a></li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>

    <!-- Vision and Mission -->
    <div>
        <h2>Department of <?php echo $departments[$department]['name']; ?></h2>

        <h4>Vision</h4>
        <ul>
            <?php foreach ($departments[$department]['vision'] as $v): ?>
                <li><?php echo $v; ?></li>
            <?php endforeach; ?>
        </ul>

        <h4>Mission</h4>
        <ul>
            <?php foreach ($departments[$department]['mission'] as $m): ?>
                <li><?php echo $m; ?></li>
            <?php endforeach; ?>
        </ul>
    </div>

    <!-- Topics Navigation + Content -->
    <div class="row mt-5">
        <!-- Nav-pills -->
        <div class="col-md-3">
            <ul class="nav nav-pills flex-column" id="topicTabs" role="tablist">
                <?php
                $first = true;
                foreach ($departments[$department]['topics'] as $topic => $details):
                    $id = strtolower($topic);
                    $active = $first ? 'active' : '';
                    echo "<li class='nav-item' role='presentation'>
                            <button class='nav-link $active' id='tab-$id' data-bs-toggle='pill' data-bs-target='#content-$id' type='button' role='tab'>$topic</button>
                        </li>";
                    $first = false;
                endforeach;
                ?>
            </ul>
        </div>

        <!-- Tab Content -->
        <div class="col-md-9">
            <div class="tab-content" id="topicTabContent">
                <?php
                $first = true;
                foreach ($departments[$department]['topics'] as $topic => $details):
                    $id = strtolower($topic);
                    $active = $first ? 'show active' : '';
                    ?>
                    <div class="tab-pane fade <?php echo $active; ?>" id="content-<?php echo $id; ?>" role="tabpanel">
                        <div class="card mb-3">
                            <div class="row g-0">
                                <div class="col-md-4">
                                    <img src="<?php echo $details['image']; ?>" class="img-fluid rounded-start" alt="<?php echo $topic; ?>">
                                </div>
                                <div class="col-md-8">
                                    <div class="card-body">
                                        <h5 class="card-title"><?php echo $topic; ?></h5>
                                        <p class="card-text"><?php echo $details['description']; ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                    $first = false;
                endforeach;
                ?>
            </div>
        </div>
    </div>

</div>

</body>

</html>
<?php include('common/footer.php') ?>   