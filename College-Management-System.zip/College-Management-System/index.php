<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Royal Technical Colleges</title>
	<link rel="shortcut icon" href="Images/LOGO.jpeg" type="image/x-icon">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
	<style>
  body {
  background-color: #fdfdfd;
  font-family: 'Segoe UI', sans-serif;
  color: #333;
  margin: 0;
  padding: 0;
}

/* Section Heading */
.heading {
  text-align: center;
  font-size: 2.5rem;
  font-weight: 700;
  color: #a1003d;
  margin-top: 3rem;
  position: relative;
}

.heading::before {
  content: '';
  display: block;
  width: 60px;
  height: 5px;
  background-color: #ffda00;
  border-radius: 8px;
  margin: 0.5rem auto;
}

/* Feature/Ranking Cards */
.card-box {
  background: #ffffff;
  border-radius: 15px;
  padding: 25px 20px;
  margin-bottom: 20px;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.06);
  text-align: center;
  transition: transform 0.3s ease-in-out, box-shadow 0.3s;
}

.card-box:hover {
  transform: translateY(-7px);
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
}

.card-box img {
  max-height: 65px;
  object-fit: contain;
  margin-bottom: 15px;
}

/* Card Text */
.card-title {
  font-weight: 700;
  font-size: 1.3rem;
  color: #000;
  margin-bottom: 0.5rem;
}

.card-text {
  font-size: 1rem;
  font-weight: 500;
  color: #444;
}

/* Placement Logos */
.logo-card {
  background: #ffffff;
  padding: 20px;
  margin: 15px 0;
  border-radius: 12px;
  box-shadow: 0 6px 18px rgba(0, 0, 0, 0.04);
  text-align: center;
  transition: transform 0.3s ease-in-out;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100px;
}

.logo-card:hover {
  transform: scale(1.06);
}

.logo-card img {
  max-height: 55px;
  width: auto;
  object-fit: contain;
}

/* Intro Paragraph */
.paragraph {
  padding: 20px 15px;
  text-align: center;
  max-width: 900px;
  margin: 0 auto;
  font-size: 1.1rem;
  color: #555;
  line-height: 1.6;
}

/* Subheadings for Steps or Info */
.in-ad-ap h3 {
  background-color: #f1f3f5;
  padding: 1rem 1.5rem;
  border-radius: 10px;
  font-weight: 600;
  margin-bottom: 1.5rem;
  color: #003366;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
}

</style>
</head>

<body>
	<?php include('common/header.php') ?>
	<div class="home-div"></div>
	<div class="w-100 in-ad-ap">
		<div class="row m-auto text-center">
			<div class="col-md-4">
				<h3>INTRODUCING-RTC</h3>
			</div>
			<div class="col-md-4">
				<h3>ADMISSION POLICY</h3>
			</div>
			<div class="col-md-4">
				<h3>APPLY NOW</h3>
			</div>
		</div>
	</div>
	<div class="paragraph">
		<p>
			Royal Technical College (RTC) provides a harmonious environment and abundant learning opportunities to its
			students, embracing diversity across gender, socioeconomic background, religious beliefs, and regional
			differences
		</p>
	</div>

	<?php include('common/cards.php') ?>



	<div class="container my-4">
  <h2 class="heading">Our Accreditations & Rankings</h2>
  <div class="row justify-content-center">
    <div class="col-md-6 col-lg-6">
      <div class="card-box">
        <img src="Images/nirf.jpg" alt="NIRF Logo" />
        <div class="card-title">6th RANKED 2023</div>
        <div class="card-text">6th Ranked University in India</div>
      </div>
    </div>
    <div class="col-md-6 col-lg-6">
      <div class="card-box">
        <img src="Images/naac.jpg">
        <div class="card-title">NAAC A+ ACCREDITED</div>
        <div class="card-text">Topmost 'A+' Grade</div>
      </div>
    </div>
    <div class="col-md-6 col-lg-6">
      <div class="card-box">
        <img src="Images/3rd.jpg" alt="THE Rankings Logo">
        <div class="card-title">No.2 IN INDIA - THE IMPACT RANKINGS 2024</div>
        <div class="card-text">Royal Technical College No.2 in India</div>
      </div>
    </div>
  </div>
</div>






<div class="container">
  <div class="heading">Placements</div>
  <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4 mt-4">
    <div class="col">
      <div class="logo-card">
        <img src="https://upload.wikimedia.org/wikipedia/commons/a/a9/Amazon_logo.svg" alt="Amazon">
      </div>
    </div>
    <div class="col">
      <div class="logo-card">
        <img src="https://upload.wikimedia.org/wikipedia/commons/2/2f/Google_2015_logo.svg" alt="Google">
      </div>
    </div>
    <div class="col">
      <div class="logo-card">
        <img src="Images/Arista.jpg" alt="Arista">
      </div>
    </div>
    <div class="col">
      <div class="logo-card">
        <img src="Images/Atlassian.jpg" alt="Atlassian">
      </div>
    </div>
    <div class="col">
      <div class="logo-card">
        <img src="Images/Bosch.jpg" alt="Bosch">
      </div>
    </div>
    <div class="col">
      <div class="logo-card">
        <img src="https://upload.wikimedia.org/wikipedia/commons/5/51/IBM_logo.svg" alt="IBM">
      </div>
    </div>
  </div>
</div>




<!-- Steps Section -->
<div class="container my-5">
  <h2 class="heading">Steps to Placement</h2>
  <div class="row text-center">
    <div class="col-md-3">
      <div class="card-box">
        <div class="card-title">Step 1</div>
        <div class="card-text">Resume Building</div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card-box">
        <div class="card-title">Step 2</div>
        <div class="card-text">Skill Development</div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card-box">
        <div class="card-title">Step 3</div>
        <div class="card-text">Mock Interviews</div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card-box">
        <div class="card-title">Step 4</div>
        <div class="card-text">Final Placement Drive</div>
      </div>
    </div>
  </div>
</div>











	<?php include('common/footer.php') ?>

</body>

</html>