<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Royal Technical Colleges</title>
    <link rel="shortcut icon" href="Images/LOGO.jpeg" type="image/x-icon">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        /* Gallery Container */
        .gallery-item {
            margin-bottom: 30px;
        }

        /* Card Styling for Image */
        .gallery-item .card {
            border: none;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            background-color: #fff;
        }

        /* Hover Effect */
        .gallery-item .card:hover {
            transform: scale(1.03);
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
        }

        /* Image Style */
        .gallery-img {
            width: 100%;
            height: 250px;
            object-fit: cover;
            border-radius: 12px;
            transition: transform 0.3s ease;
        }

        /* Responsive Height Adjustments */
        @media (max-width: 768px) {
            .gallery-img {
                height: 200px;
            }
        }

        @media (max-width: 576px) {
            .gallery-img {
                height: 180px;
            }
        }
    </style>




</head>

<body>

    <?php include('common/header.php') ?>
    <div class="container my-5">
        <h1 class="text-center mb-4">College Gallery</h1>

        <!-- Bootstrap Grid Layout -->
        <div class="row">
            <!-- Image 1 -->
            <div class="col-md-4 gallery-item">
                <div class="card">
                    <img src="img/1.jpeg" class="card-img-top gallery-img" alt="Gallery Image 1">
                </div>
            </div>
            <!-- Image 2 -->
            <div class="col-md-4 gallery-item">
                <div class="card">
                    <img src="img/2.jpeg" class="card-img-top gallery-img" alt="Gallery Image 2">
                </div>
            </div>
            <!-- Image 3 -->
            <div class="col-md-4 gallery-item">
                <div class="card">
                    <img src="img/3.jpeg" class="card-img-top gallery-img" alt="Gallery Image 3">
                </div>
            </div>
            <!-- Image 4 -->
            <div class="col-md-4 gallery-item">
                <div class="card">
                    <img src="img/4.jpg" class="card-img-top gallery-img" alt="Gallery Image 4">
                </div>
            </div>
            <!-- Image 5 -->
            <div class="col-md-4 gallery-item">
                <div class="card">
                    <img src="img/5.jpg" class="card-img-top gallery-img" alt="Gallery Image 5">
                </div>
            </div>
            <!-- Image 6 -->
            <div class="col-md-4 gallery-item">
                <div class="card">
                    <img src="img/6.jpg" class="card-img-top gallery-img" alt="Gallery Image 6">
                </div>
            </div>
            <!-- Image 7 -->
            <div class="col-md-4 gallery-item">
                <div class="card">
                    <img src="img/7.jpg" class="card-img-top gallery-img" alt="Gallery Image 7">
                </div>
            </div>
            <!-- Image 8 -->
            <div class="col-md-4 gallery-item">
                <div class="card">
                    <img src="img/8.jpg" class="card-img-top gallery-img" alt="Gallery Image 8">
                </div>
            </div>
            <!-- Image 9 -->
            <div class="col-md-4 gallery-item">
                <div class="card">
                    <img src="img/10.jfif" class="card-img-top gallery-img" alt="Gallery Image 9">
                </div>
            </div>
            <!-- Image 10 -->
            <div class="col-md-4 gallery-item">
                <div class="card">
                    <img src="img/11.jpg" class="card-img-top gallery-img" alt="Gallery Image 10">
                </div>
            </div>
            <!-- Image 11 -->
            <div class="col-md-4 gallery-item">
                <div class="card">
                    <img src="img/12.png" class="card-img-top gallery-img" alt="Gallery Image 11">
                </div>
            </div>
            <!-- Image 12 -->
            <div class="col-md-4 gallery-item">
                <div class="card">
                    <img src="img/13.jpeg" class="card-img-top gallery-img" alt="Gallery Image 12">
                </div>
            </div>
        </div>
    </div>

    <button id="backToTop" onclick="scrollToTop()">↑</button>
    <script>
        window.onscroll = function () {
            const btn = document.getElementById("backToTop");
            btn.style.display = window.scrollY > 300 ? "block" : "none";
        };

        function scrollToTop() {
            window.scrollTo({ top: 0, behavior: "smooth" });
        }
    </script>


</body>

</html>
<?php include('common/footer.php') ?>