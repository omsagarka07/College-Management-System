<?php 
$con = mysqli_connect("localhost", "root", "", "college");

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
