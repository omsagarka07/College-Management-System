<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Royal Technical Colleges</title>
  <link rel="shortcut icon" href="Images/LOGO.jpeg" type="image/x-icon">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>
  <?php include('common/header.php'); ?>
  <div class="container">
    <div class="row pt-2">
      <div class="col-12">
        <div class="bg-info text-center text-white py-3">
          <h4>Online Admission Form</h4>
        </div>
      </div>
    </div>

    <form action="student.php" method="POST" enctype="multipart/form-data" class="m-3">
      <div class="row">
        <div class="col-md-4">
          <label for="first_name">Applicant First Name:*</label>
          <input type="text" id="first_name" name="first_name" class="form-control" required>
        </div>
        <div class="col-md-4">
          <label for="middle_name">Applicant Middle Name:</label>
          <input type="text" id="middle_name" name="middle_name" class="form-control">
        </div>
        <div class="col-md-4">
          <label for="last_name">Applicant Last Name:*</label>
          <input type="text" id="last_name" name="last_name" class="form-control" required>
        </div>
      </div>

      <div class="row mt-3">
        <div class="col-md-4">
          <label for="father_name">Father Name:*</label>
          <input type="text" id="father_name" name="father_name" class="form-control" required>
        </div>
        <div class="col-md-4">
          <label for="email">Applicant Email:*</label>
          <input type="email" id="email" name="email" class="form-control" required
            pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$">
        </div>
        <div class="col-md-4">
          <label for="mobile_no">Mobile No:*</label>
          <input type="tel" id="mobile_no" name="mobile_no" class="form-control" required>
        </div>
      </div>

      <div class="row mt-3">
        <div class="col-md-4">
          <label for="profile_image">Your Profile Image:</label>
          <input type="file" id="profile_image" name="profile_image" class="form-control">
        </div>
        <div class="col-md-4">
          <label for="prospectus_issued">Prospectus Issued:</label>
          <select id="prospectus_issued" name="prospectus_issued" class="custom-select">
            <option>Select Option</option>
            <option value="Yes">Yes</option>
            <option value="No">No</option>
          </select>
        </div>
        <div class="col-md-4">
          <label for="prospectus_amount">Prospectus Amount Received:</label>
          <select id="prospectus_amount" name="prospectus_amount" class="custom-select">
            <option>Select Option</option>
            <option value="Yes">Yes</option>
            <option value="No">No</option>
          </select>
        </div>
      </div>

      <div class="row mt-3">
        <div class="col-md-4">
          <label for="form_b">Form B:</label>
          <input type="text" id="form_b" name="form_b" class="form-control">
        </div>
        <div class="col-md-4">
          <label for="applicant_status">Applicant Status:</label>
          <select id="applicant_status" name="applicant_status" class="custom-select">
            <option>Select Option</option>
            <option value="Admitted">Admitted</option>
            <option value="Not Admitted">Not Admitted</option>
          </select>
        </div>
        <div class="col-md-4">
          <label for="application_status">Application Status:</label>
          <select id="application_status" name="application_status" class="custom-select">
            <option>Select Option</option>
            <option value="Approved">Approved</option>
            <option value="Not Approved">Not Approved</option>
          </select>
        </div>
      </div>

      <div class="row mt-3">
        <div class="col-md-4">
          <label for="cnic">CNIC No:</label>
          <input type="text" id="cnic" name="cnic" class="form-control" placeholder="XXXXX-XXXXXXX-X">
        </div>
        <div class="col-md-4">
          <label for="dob">Date of Birth:</label>
          <input type="date" id="dob" name="dob" class="form-control">
        </div>
        <div class="col-md-4">
          <label for="other_phone">Other Phone:</label>
          <input type="tel" id="other_phone" name="other_phone" class="form-control">
        </div>
      </div>

      <div class="row mt-3">
        <div class="col-md-4">
          <label for="gender">Gender:</label>
          <select id="gender" name="gender" class="custom-select">
            <option>Select Gender</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
          </select>
        </div>
        <div class="col-md-4">
          <label for="permanent_address">Permanent Address:</label>
          <input type="text" id="permanent_address" name="permanent_address" class="form-control">
        </div>
        <div class="col-md-4">
          <label for="current_address">Current Address:</label>
          <input type="text" id="current_address" name="current_address" class="form-control">
        </div>
      </div>

      <div class="row mt-3">
        <div class="col-md-4">
          <label for="place_of_birth">Place of Birth:</label>
          <input type="text" id="place_of_birth" name="place_of_birth" class="form-control">
        </div>
        <div class="col-md-4">
          <label for="matric_completion_date">Matric/O-Level Completion Date:</label>
          <input type="date" id="matric_completion_date" name="matric_complition_date" class="form-control">
        </div>
        <div class="col-md-4">
          <label for="matric_awarded_date">Matric/O-Level Awarded Date:</label>
          <input type="date" id="matric_awarded_date" name="matric_awarded_date" class="form-control">
        </div>
      </div>

      <div class="row mt-3">
        <div class="col-md-4">
          <label for="matric_certificate">Upload Matric/O-Level Certificate:</label>
          <input type="file" id="matric_certificate" name="matric_certificate" class="form-control">
        </div>
        <div class="col-md-4">
          <label for="fa_completion_date">FA/A-Level Completion Date:</label>
          <input type="date" id="fa_completion_date" name="fa_complition_date" class="form-control">
        </div>
        <div class="col-md-4">
          <label for="fa_awarded_date">FA/A-Level Awarded Date:</label>
          <input type="date" id="fa_awarded_date" name="fa_awarded_date" class="form-control">
        </div>
      </div>

      <div class="row mt-3">
        <div class="col-md-4">
          <label for="fa_certificate">Upload FA/A-Level Certificate:</label>
          <input type="file" id="fa_certificate" name="fa_certificate" class="form-control">
        </div>
        <div class="col-md-4">
          <label for="ba_completion_date">BA Completion Date:</label>
          <input type="date" id="ba_completion_date" name="ba_complition_date" class="form-control">
        </div>
        <div class="col-md-4">
          <label for="ba_awarded_date">BA Awarded Date:</label>
          <input type="date" id="ba_awarded_date" name="ba_awarded_date" class="form-control">
        </div>
      </div>

      <div class="row mt-3">
        <div class="col-md-4">
          <label for="ba_certificate">Upload BA Certificate:</label>
          <input type="file" id="ba_certificate" name="ba_certificate" class="form-control">
        </div>
      </div>

      <div class="row mt-4">
        <div class="col-12 text-center">
          <button type="submit" class="btn btn-success">Submit Application</button>
        </div>
      </div>
    </form>
  </div>
</body>

</html>
<?php include('common/footer.php') ?>
